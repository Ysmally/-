package com.example.word;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordApplicationTests {

    @Test
    void contextLoads() {
    }

}
