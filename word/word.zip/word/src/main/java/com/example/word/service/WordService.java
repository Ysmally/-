package com.example.word.service;

public class WordService {
}
