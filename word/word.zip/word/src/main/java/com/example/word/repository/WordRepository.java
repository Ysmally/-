package com.example.word.repository;

public class WordRepository {
}
